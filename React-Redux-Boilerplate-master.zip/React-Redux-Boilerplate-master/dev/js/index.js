import 'babel-polyfill';
import React from 'react';
import ReactDOM from "react-dom";



ReactDOM.render(<h1>Hey</h1>,
    document.getElementById('root')
);
